<?php
/**
 * Template Name:OUR APPROACH
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

<!-- banner section-->
<!-- banner section-->
		<section>
			<div class="banner_section">
				<div class="container">
					<div class="col-md-12">				
						<?php echo do_shortcode('[crellyslider alias="our_approach_page"] '); ?>
					</div>
					</div>
</div>
</section>
<section class="about_pagesection">
	<div class="container">
      	<h3 class="aboutpage_head text-center"><?php the_field('our_approach_main_heading',22);?></h3>
<p class="text-center ourapproachpt-10"><span class="checktext"><?php the_field('our_approach_sub_heading',22);?></span></p>
<div class="whyus_section2">
	
        <div class="col-xs-3 col-md-6 col-sm-6">
            <!-- required for floating -->
            <!-- Nav tabs -->
<p class="ourapproach_tabheading"><?php the_field('our_approach_tab_section_heading',22);?></p>
            <ul class="nav nav-tabs tabs-left">
	
          <?php
      $count=0;
      if( have_rows('tab_menu_repeator',22) ){
         while ( have_rows('tab_menu_repeator',22) ) : the_row();
         $icon=get_sub_field('tab_menu_repeator_icon',22);
         $heading=get_sub_field('tab_menu_repeator_heading',22);
         $subheading=get_sub_field('tab_menu_repeator_subheading',22);
    ?>
 <li class="<?php if($count==0){echo 'active';}?>"><a href="#home<?php echo $count; ?>" data-toggle="tab"><span class="tabs_icons"><img src="<?php echo $icon; ?>" class="img-responsive"></span><p class="tab_menu_heading"><?php echo $heading; ?></p><p class="tab_section_sub_heading"><?php echo $subheading;?></p></a></li>
 <?php
         $count++;
         endwhile;
         }
         else{
       echo"No Images Found";
         }
     ?>
            </ul>
        </div>
        <div class="col-xs-9 col-md-6 col-sm-6">
            <!-- Tab panes -->
            <div class="tab-content">
                <?php
      $count=0;
      if( have_rows('tab_content_repeator',22) ){
         while ( have_rows('tab_content_repeator',22) ) : the_row();
         $image=get_sub_field('tab_content_repeator_image',22);
         $content=get_sub_field('tab_content_repeator_content',22);
         
    ?>
<div class="tab-pane <?php if($count==0){echo 'active';}?>" id="home<?php echo $count; ?>"><img src="<?php echo $image;?>" class="img-responsive">
<p class="ourappro_tabs_content_se"><?php echo $content; ?></p></div>

 <?php
         $count++;
         endwhile;
         }
         else{
       echo"No Images Found";
         }
     ?>
                
                
            </div>
        </div>
       
</div>
</div>
</section>

<?php get_footer(); ?>