<?php
/**
 * Template Name:WHY US
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

<!-- banner section-->
<!-- banner section-->
		<section>
			<div class="banner_section">
				<div class="container">
					<div class="col-md-8">				
						<?php echo do_shortcode('[crellyslider alias="banner_slider"] '); ?>
					</div>
					<div class="col-md-4">
						<h3 class="portfolio_head"><?php the_field('banner_right_heading',20); ?></h3>
						<?php
      $count=0;
      if( have_rows('banner_right_repeator',20) ){
         while ( have_rows('banner_right_repeator',20) ) : the_row();
         $text=get_sub_field('banner_right_repeator_content',20);
    ?>
    <p><i class="fa fa-check checkcolor"></i><span class="checktext"><?php echo $text; ?></span></p>
 <?php
         $count++;
         endwhile;
         }
         else{
       echo"No Images Found";
         }
     ?>
<div class="row rr whyusmt">
	<div class="col-md-8 col-sm-8 col-xs-8">
               <input type="button" class="whyusbitt" value="<?php the_field('banner_right_button',20); ?>">
        </div>
<div class="col-md-4 col-sm-4 col-xs-4">
	<img src="<?php the_field('banner_right_button_after_image',20); ?>" class="img-responsive">
</div>
</div>
					</div>
				</div>
			</div>
		</section>
<section class="about_pagesection whyus_pagebgcolor">
	<div class="container">
      	<h3 class="aboutpage_head text-center"><?php the_field('whyus_section2_heading',20);?></h3>
<p class="text-center whyus_paddingtb"><span class="checktext"><?php the_field('whyus_section2_subheading',20);?></span></p>
<img src="<?php the_field('whyus_section2_line',20)?>" class="img-responsive center-block">
<div class="whyus_section2">
	<div class="col-md-4 col-sm-4 why_us_section_hover">
		<p class="whyus_section2_height"><i class="fa fa-user whyus_section2_icon"></i><span class="whyus_section2_heading"><?php the_field('whyus_section2_line_after_heading1',20);?></span></p>
<p class="whyus_section2_text"><?php the_field('whyus_section2_line_after_content1',20); ?></p>
	</div>
<div class="col-md-4 col-sm-4 why_us_section_hover">
		<p class="whyus_section2_height"><i class="fa fa-map-marker whyus_section2_icon"></i><span class="whyus_section2_heading"><?php the_field('whyus_section2_line_after_heading2',20); ?></span></p>
<p class="whyus_section2_text"><?php the_field('whyus_section2_line_after_content2',20);?></p>
	</div>
<div class="col-md-4 col-sm-4 why_us_section_hover">
		<p class="whyus_section2_height"><i class="fa  fa-shopping-bag whyus_section2_icon"></i><span class="whyus_section2_heading"><?php the_field('whyus_section2_line_after_heading3',20); ?></span></p>
<p class="whyus_section2_text"><?php the_field('whyus_section2_line_after_content3',20); ?></p>
	</div>
</div>
	</div>
</section>
<section class="about_pagesection">
	<div class="container">
      	<h3 class="aboutpage_head text-center"><?php the_field('whyus_section3_heading',20);?></h3>
<p class="text-center whyus_paddingtb"><span class="checktext"><?php the_field('whyus_section3_subheading',20);?></span></p>
<img src="<?php the_field('whyus_section2_line',20)?>" class="img-responsive center-block">

<?php
      $count=0;
      if( have_rows('whyus_section3_repeator',20) ){
         while ( have_rows('whyus_section3_repeator',20) ) : the_row();
         $heading=get_sub_field('whyus_section3_repeator_heading',20);
         $content=get_sub_field('whyus_section3_repeator_content',20);
    ?>
<div class="whyus_section3">
    <p class=""><span class="whyus_section2_heading"><?php echo $heading; ?></span></p>
<p class="whyus_section2_text"><?php echo $content; ?></p>
</div>
 <?php
         $count++;
         endwhile;
         }
         else{
       echo"No Images Found";
         }
     ?>


</div>
</section>

<?php get_footer(); ?>