<?php
/**
 * Template Name:CONTACT
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>
		
		<!-- banner section-->
		<section>
			<div class="banner_section">
				<div class="container">
					<div class="col-md-12">
						<?php echo do_shortcode('[crellyslider alias="contactpage_banner"] '); ?>
					</div>
				</div>
				<!--<div id="myCarousel1" class="carousel slide" data-ride="carousel">
					 Wrapper for slides 
					<div class="carousel-inner">
						<div class="item active">
							<div class="abtbanner">
								<img src="images/bannercontact.png" alt="Los Angeles" class="img-responsive banner_img">
								<p class="bannerabt_text">Contact Us</p>
							</div>
						</div>
						<div class="item">
							<div class="abtbanner">
								<img src="images/bannercontact.png" alt="Los Angeles" class="img-responsive banner_img">
								<p class="bannerabt_text">Contact Us</p>
							</div>
						</div>
						<div class="item">
							<div class="abtbanner">
								<img src="images/bannercontact.png" alt="Los Angeles" class="img-responsive banner_img">
								<p class="bannerabt_text">Contact Us</p>
							</div>
						</div>
					</div>
				</div>-->
			</div>
		</section>
		<!--  contact us -->
		<section>
			<div class="contact_uspage_section">
				<div class="container">
					<div class="testmonialabt_head text-center">
						<p class="testabt_heah"><?php the_field('contactpage_head',6)?></p>
						<hr class="test_hr1 contahr"></hr>
					</div>
					<div class="col-md-3 col-sm-6 cont_sect1">
						<div class="addres_sectcont text-center">
							<i class="fa <?php the_field('contactpage_firstsection_icon',6)?> homemen_conicon"></i>
							<h3 class="addrescontact"><?php the_field('contactpage_firstsection_home',6)?></h3>
							<p class="addres_detain_contact"><?php the_field('contactpage_firstsection_addressdetail',6)?></p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 cont_sect1">
						<div class="addres_sectcont text-center">
							<i class="fa <?php the_field('contactpage_secondsection_icon',6)?> homemen_conicon"></i>
							<h3 class="addrescontact"><?php the_field('contactpage_secondection_mobilenumber',6)?></h3>
							<p class="addres_detain_contact"><?php the_field('contactpage_secondection_number1',6)?></p>
							<p class="addres_detain_contact"><?php the_field('contactpage_secondection_number2',6)?></p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 cont_sect1">
						<div class="addres_sectcont text-center">
							<i class="fa <?php the_field('contactpage_thirdsect_icon',6)?> homemen_conicon"></i>
							<h3 class="addrescontact"><?php the_field('contactpage_thirdsect_faxtext',6)?></h3>
							<p class="addres_detain_contact"><?php the_field('contactpage_thirdsect_faxnumber1',6)?></p>
							<p class="addres_detain_contact"><?php the_field('contactpage_thirdsect_faxnumber2',6)?></p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 cont_sect1">
						<div class="addres_sectcont text-center">
							<i class="fa <?php the_field('contact_page_fourthsection_icon',6)?> homemen_conicon"></i>
							<h3 class="addrescontact"><?php the_field('contact_page_fourthsection_emailtext',6)?></h3>
							<p class="addres_detain_contact"><?php the_field('contact_page_fourthsection_email1',6)?></p>
							<p class="addres_detain_contact"><?php the_field('contact_page_fourthsection_email2',6)?></p>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- map section-->
		<section>
			<div class="img_mapfull">
				<div class="imagemap image-responsive">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3647240.4142957944!2d11.19397737424953!3d50.858139257028725!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x479a721ec2b1be6b%3A0x75e85d6b8e91e55b!2sGermany!5e0!3m2!1sen!2sin!4v1499350374784" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
				</div>
			</div>
		</section>
		<!--touch us-->
		<section>
			<div class="contact_section">
				<div class="container">
					<div class="testmonialabt_head text-center">
						<p class="testabt_heah"><?php the_field('get_touch_head',6)?></p>
						<hr class="test_hr1 touchhr"></hr>
					</div>
					<?php echo do_shortcode('[contact-form-7 id="194" title="Contact form 1"]'); ?>
					
					<!--<form class="for_wid">
						<div class="col-md-4 col-sm-4 col-xs-12">
							<input class="form_name" type="text" placeholder="Name" required="" name="Name">
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<input class="form_name" type="email" placeholder="E-mail ID" required="" name="E-mail">
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<input class="form_name" type="number" placeholder="Mobile No" required="" name="E-mail">
						</div>
						<div class="col-md-12 col-sm-12 col-xs-12">
							<textarea class="form_text" type="text" placeholder="Message"  required="" name="Message"></textarea>
						</div>
						<div class="cont_button text-center"> 
							<button class="submit_contactbutton" type="submit">Submit</button>
						</div>
					</form>-->
				</div>
			</div>
		</section>
	
	<?php get_footer(); ?>