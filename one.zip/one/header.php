<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri();?>/assets/images/fav_icon.png"/>-->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	 <title>Development</title>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/font-awesome.css"/>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/style.css"/>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/owl.carousel.css"/>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/animate.css"/>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/style.css"/>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/jquery-1.11.3.min.js"></script> 
	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/owl.carousel.js" type="text/javascript"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/wow.min.js"></script>
	<script>
		new WOW().init();
	</script>

<?php wp_head(); ?>
</head>
<body id="trans">
		<!-- header section-->
		<header>
			<div class="head_sect">
				<div class="container continq">
					<div class="col-md-7 col-sm-7 pl padd_cls">
						<div class="con_no wow fadeInDown">
							<a class="clr" href="mailto:<?php the_field('header_mail_id',17)?>">
							<p class="con_de"><span class="fo_clr"><i class="fa <?php the_field('header_globe_icon',17)?>"></i></span> <?php the_field('header_mail_id',17)?></p></a>
						</div>
						<div class="con_nophone wow fadeInUp">
							<a class="clr" href="tel:  <?php the_field('header_phone_num',17)?>">
							<p class="con_de"><span class="fo_clr"><i class="fa <?php the_field('header_phone_num_icon',17)?> "></i></span> <?php the_field('header_phone_num',17)?></p></a>
						</div>
					</div>
					<div class="col-md-5 col-sm-5 pr text-right wow fadeInDown">
						<ul class="list-inline socialser wow fadeInRight">
							<li><a href="<?php the_field('header_font_facebook_url',17)?>"><span><i class="fa <?php the_field('header_facebook_icon',17)?>"></i></span><?php the_field('header_facebook_text',17)?></a></li>
							<li><a href="<?php the_field('header_font_facebook_url',17)?>"><span><i class="fa <?php the_field('header_twitter_icon',17)?>"></i></span><?php the_field('header_twitter_text',17)?></a></li>
							<li><a href="<?php the_field('header_font_facebook_url',17)?>"><span><i class="fa <?php the_field('header_linkedin_icon',17)?>"></i></span><?php the_field('header_linkedin_text',17)?></a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- logo section-->
			<div class="logo_section">
				<div class="container">
					<div class="col-md-3 col-sm-3 web_logo">
						<a href="<?php echo site_url();?>">
						<img src="<?php the_field('header_logo_img',17)?>" class="img-responsive img_logo"></a>
					</div>
					<div class="col-md-6 col-sm-7 lead_sect">
						<div class="col-md-4 col-sm-5 leading_section xswid1">
							<p class="lead_detail"><b><span class="fo_clrw"><i class="fa <?php the_field('ledaing_provider_icon',17)?>"></i></span> <?php the_field('leading_provider_head',17)?></b></p></a>
							<p class="lead_industrial"><?php the_field('leading_provider_para1',17)?></p>
						</div>
						<div class="col-md-4 col-sm-4 leading_section xswidth2">
							<p class="lead_detail"><b><span class="fo_clrw"><i class="fa <?php the_field('ledaing_provider_icon2',17)?>"></i></span> <?php the_field('leading_provider_head2',17)?></b></p></a>
							<p class="lead_industrial"><?php the_field('leading_provider_para2',17)?></p>
						</div>
						<div class="col-md-4 col-sm-3 leading_section xswidth3">
							<p class="lead_detail"><b><span class="fo_clrw"><i class="fa <?php the_field('ledaing_provider_icon3',17)?>"></i></span> <?php the_field('leading_provider_head3',17)?></b></p></a>
							<p class="lead_industrial"><?php the_field('leading_provider_para3',17)?></p>
						</div>
					</div>
					<div class="col-md-3 col-sm-2 search_sect">
						<!--form>
							<div class="input-group add-on">
								<input class="form-control" placeholder="Search..." name="srch-term" id="srch-term" type="text">
								<div class="input-group-btn">
									<button class="btn btn-default serch_buton" type="submit"><i class="fa fa-search"></i></button>
								</div>
							</div>
						</form-->
						<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
						 <div class="input-group add-on">
						  <input type="search" class="search-field form-control" id="search_home" placeholder="<?php echo esc_attr_x( 'Search... ', 'placeholder', 'twentysixteen' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
						 <div class="input-group-btn">
						  <button type="submit" class="search-submit btn btn-default serch_btn"><span class="screen-reader-text"><i class="fa fa-search"></i></span></button>
						 </div>
						 </div>
						</form>
					</div>
				</div>
			</div>
			<!-- menu sectio-->
			<div class="menu section">
				<div class="container">
					<div class="navbar-header col-xs-4 padnh">
						<button type="button" class="pop navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>
							<span class="icon-bar cc"></span>
							<span class="icon-bar"></span>                        
						</button>
					</div>
					<div class="col-md-9 col-sm-9 menu_sect">
						<div class="collapse navbar-collapse" id="myNavbar">
							<!--<ul class="list-inline menu_inline">
								<li class="active"><a href="index.html">HOME</a></li>
								<!-- <li><a href="index.html">SOLUTIONS</a></li> -->
								<!--<li class="dropdown">
									<a href="#" data-toggle="dropdown" class="dropdown-toggle">SOLUTIONS <b class="care"> <i class="fa fa-angle-down cart_icon"></i></b></a>
									<ul class="dropdown-menu">
										<li class="drop_submen"><a href="#">drop1</a></li>
										<li class="drop_submen"><a href="#">drop2</a></li>
									</ul>
								</li>
								<li><a href="index.html">TESTIMONIALS</a></li>
								 <li class="dropdown">
									<a href="#" data-toggle="dropdown" class="dropdown-toggle">NEWS <b class="care"><i class="fa fa-angle-down cart_icon"></i></b></a>
									<ul class="dropdown-menu">
										<li class="drop_submen"><a href="#">drop3</a></li>
										<li class="drop_submen"><a href="#">drop17</a></li>
									</ul>
								</li>
								<li><a href="index.html">ABOUT</a></li>
								<li><a href="index.html">SHOP</a></li>
								<li><a href="index.html">CONTACT</a></li>
							</ul>-->
							
							<ul class="nav navbar-nav list-inline menu_inline">
								  <?php
								   wp_nav_menu( array(
									'theme_location' => 'primary',
									'menu_class'     => 'nav navbar-nav list-inline menu_inline',
									'walker'            => new WP_Bootstrap_Navwalker(),
									) );
								  ?>
								 </ul>
							<?php
								//wp_nav_menu( array(
									//'menu'              => 'primary',
									//'theme_location'    => 'primary',
									//'depth'             => 2,
									//'container'         => 'div',
									//'container_class'   => 'collapse navbar-collapse',
									//'container_id'      => 'bs-example-navbar-collapse-1',
									//'menu_class'        => 'list-inline menu_inline',
									//'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
									//'walker'            => new WP_Bootstrap_Navwalker())
								//);
							?>
						</div>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-8 text-right download_but">
						<a href="<?php the_field('download_url',17)?>" class="download_detail"><span class="fo_clrwdm"><i class="fa <?php the_field('download_icon',17)?> "></i></span> <?php the_field('download_text',17)?></a>
						<a href="./shop/" class="download_deta"><span class="fo_clrwdm"><i class="fa <?php the_field('quate_icon',17)?>"></i></span> <?php the_field('quate_text',17)?></a>
						
					</div>
				</div>
			</div>		
		</header>
