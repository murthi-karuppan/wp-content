<?php
/**
 * Template Name:PRODUCT
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

<!-- banner section-->
<!-- banner section-->
		<section>
			<div class="banner_section">
				<div class="container">
					<div class="col-md-12">				
						<?php echo do_shortcode('[crellyslider alias="product_page"]'); ?>
					</div>
					</div>
</div>
</section>
<section class="about_pagesection product_page">

<div class="container"><div class="testmonialabt_head text-center">
						<p class="testabt_heah">Produkte</p>
						<hr class="test_hr1 contahr">
					</div><?php echo do_shortcode('[products]'); ?></div>
</section>
<?php get_footer(); ?>