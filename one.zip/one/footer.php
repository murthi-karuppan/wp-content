<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */

?>
		<section>
			<div class="contact_sectin wow fadeInLeft" data-wow-delay="0.8s">
				<div class="container">
					<div class="col-md-12 pl">
						<div class="contact_fulsect">
							<div class="col-md-4 col-sm-4 con_addrsfo wow fadeInLeft" data-wow-delay="0.9s">
								<span class="con_icon"><i class="fa <?php the_field('contact_foticon1',17)?>"></i></span>
								<div class="con_sect">
									<p class="cont_head"><?php the_field('contact_addres',17)?></p>
									<p class="conyt_para "><?php the_field('contact_addressdetail',17)?></p>
								</div>
							</div>
							<div class="col-md-4 col-sm-4 con_addrsfo wow fadeInLeft" data-wow-delay="1.0s">
								<span class="con_icon"><i class="fa <?php the_field('callus_icon1',17)?>"></i></span>
								<div class="con_sect">
									<p class="cont_head"><?php the_field('callus_head',17)?></p>
									<p class="conyt_para "><?php the_field('callus_text1',17)?></p>
									<p class="conyt_para "><?php the_field('callus_text2',17)?></p>
								</div>
							</div>
							<div class="col-md-4 col-sm-4 con_addrsfo wow fadeInLeft" data-wow-delay="1.1s">
								<span class="con_icon"><i class="fa <?php the_field('email_iconfooter',17)?>"></i></span>
								<div class="con_sect">
									<p class="cont_head"><?php the_field('email_head',17)?></p>
									<p class="conyt_para "><?php the_field('email_paratext',17)?></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- footer section-->
		<section>
			<div class="footer_section">
				<div class="container">
					
					<div class="col-md-3 col-sm-3 footer_first wow fadeInLeft" data-wow-delay="0.8s">
						<div class="footer_logo_img">
							<img src="<?php the_field('footer_logo',17)?>" class="img-responsive foot_img">
						</div>
						<p class="first_para text-justify"><?php the_field('footer_firstsection_text',17)?></p>
						<ul class="list-inline footer_sect">
							<li><i class="fa <?php the_field('footer_icon1',17)?> footer_icon"></i></li>
							<li><i class="fa <?php the_field('footer_icon2',17)?> footer_icon fa2"></i></li>
							<li><i class="fa <?php the_field('footer_icon3',17)?> footer_icon fa3"></i></li>
							<li><i class="fa <?php the_field('footer_icon4',17)?> footer_icon fa4"></i></li>
							<li><i class="fa <?php the_field('footer_icon5',17)?> footer_icon fa5"></i></li>
						</ul>
					</div>
					<div class="col-md-2 col-sm-3 footer_second wow fadeInLeft" data-wow-delay="0.9s">
						<p class="quick_links"><?php the_field('quick_links_head',17)?></p>
						<ul class="quick_menu">
							<li><a href="#"><?php the_field('quick_menu1',17)?></a></li>
							<li><a href="#"><?php the_field('quick_menu2',17)?></a></li>
							<li><a href="#"><?php the_field('quick_menu3',17)?></a></li>
							<li><a href="#"><?php the_field('quick_menu4',17)?></a></li>
							<li><a href="#"><?php the_field('quick_menu5',17)?></a></li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-3 footer_third wow fadeInRight" data-wow-delay="0.8s">
						<p class="quick_links"><?php the_field('ourservice_head',17)?></p>
						<ul class="quick_menu">
							<li><a href="#"><?php the_field('ourservice_menu1',17)?></a></li>
							<li><a href="#"><?php the_field('ourservice_menu2',17)?></a></li>
							<li><a href="#"><?php the_field('ourservice_menu3',17)?></a></li>
							<li><a href="#"><?php the_field('ourservice_menu4',17)?></a></li>
							<li><a href="#"><?php the_field('ourservice_menu5',17)?></a></li>
						</ul>
					</div>
					<div class="col-md-4 col-sm-3 footer_fourth wow fadeInRight" data-wow-delay="0.8s">
						<p class="quick_links"><?php the_field('newsletter_head',17)?></p>
						<p class="first_para text-justify fourfoo_para"><?php the_field('news_letter_para',17)?></p>
						<form id="footer_form">
							<input type="email" class="emial_subscr" placeholder="Enter Email ID">
							<button type="submit" class="subscribe_buton">SUBSCRIBE NOW</button>
						</form>
					</div>
				</div>
			</div>
			<div class="copy_right_section">
				<p class="copy_text text-center">&copy; 2017.ALL Rights are Reserved</p>
			</div>
		</section>
		</main>
	 <!-- Kick off Filterizr -->
    <script type="text/javascript">
		$(function() {
		//product owl-carousel
		$(document).ready(function(){
			$('#owl-demo2').owlCarousel({
				items:3,
				loop:true,
				margin:10,
				autoplay:true,
				autoplayHoverPause: true,
				nav:false,
				
				responsive:{
					0:{
						items:1
					},
				460:{
					items:2
				},
				620:{
					items:3
				},
				768:{
					items:3
				},
				991:{
						items:3
					},
				1200:{
						items:3
					}
				}
			});
		});
      
		$(document).ready(function(){
			$('#owl-demo').owlCarousel({
				items:5,
				loop:true,
				margin:5,
				autoplay:true,
				autoplayHoverPause: true,
				nav:true,
				
				responsive:{
					0:{
						items:1
					},
				460:{
					items:2
				},
				620:{
					items:3
				},
				768:{
					items:3
				},
				991:{
						items:4
					},
				1200:{
						items:5
					}
				}
			});
		});
		
		// testimonial section owl
				$(document).ready(function(){
					$("#testimonial-slider").owlCarousel({
						items:1,
						loop:true,
						margin:40,
						autoplay:true,
						autoplayTimeout:3000,
						autoplayHoverPause: true,
						dots:false,
						nav:true,
						responsive:{
							0:{
								items:1
							},
							400:{
								items:1
							},
							550:{
								items:1
							},
							700:{
								items:1
							},
							991:{
								items:1
							},
							1200:{
								 items:1
							}
						}
					});
					$( ".owl-next").html('<i class="fa fa-chevron-right"></i>');
					$( ".owl-prev").html('<i class="fa fa-chevron-left"></i>');
				});

		
		//xs menu
		$(document).ready(function(){
			$('.pop').click(function(){
			  $('#myNavbar').stop().toggle(500);
			  $(".pop").toggleClass("opened_menu");
			});
			$('.pop').click(function(){
				$("#trans").toggleClass("trans");
			});        
		});       
		});   
	</script> 
<?php wp_footer(); ?>

</body>
</html>
