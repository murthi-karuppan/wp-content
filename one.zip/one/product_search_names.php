<?php 
require_once($_SERVER['DOCUMENT_ROOT'] .'/wp-config.php');
//require_once( dirname( __FILE__ ) . '/wp-config.php');
require_once($_SERVER['DOCUMENT_ROOT'] .'/wp-load.php');
if(isset($_POST['product_comp_search'])){
	$pname=$_POST['product_name'];
	$pcname=$_POST['product_company_name'];
	//$dat_pro=get_comp_with_product($pname);
	//function get_comp_with_product($pname=''){

	global $wpdb;
    //print_r($wpdb);
	$angel=array();
 if($pname && $pcname){
    $angel= $wpdb->get_results( $wpdb->prepare(
        "
            SELECT * FROM schneider_posts WHERE post_title='$pname' AND post_content='$pcname'
        ",
        // Edit the table name
        "{$wpdb->prefix}_woocommerce_attribute_taxonomies"
    ) );
}
else if($pcname){
    $angel= $wpdb->get_results( $wpdb->prepare(
        "
            SELECT * FROM schneider_posts WHERE post_title='$pname' OR post_content='$pcname'
        ",
        // Edit the table name
        "{$wpdb->prefix}_woocommerce_attribute_taxonomies"
    ) );

}
else if($pname){
    $angel= $wpdb->get_results( $wpdb->prepare(
        "
            SELECT * FROM schneider_posts WHERE post_type='product' AND (post_title='$pname'   OR post_content='$pcname')
        ",
        // Edit the table name
        "{$wpdb->prefix}_woocommerce_attribute_taxonomies"
    ) );
//print_r($angel);
}
else if(!$pname && !$pcname){
    $angel= $wpdb->get_results( $wpdb->prepare(
        "
            SELECT * FROM schneider_posts WHERE post_type='product'
        ",
        // Edit the table name
        "{$wpdb->prefix}_woocommerce_attribute_taxonomies"
    ) );
}
    //print_r($angel);
   	
   	
   	foreach ($angel as $product) {
echo '<div class="col-md-3 col-sm-3 col-xs-4">
<div class="border_se">';
 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $product->ID ), 'single-post-thumbnail' );

    echo '<img src="'.$image[0].'" class="attachment-shop_catalog size-shop_catalog wp-post-image">';
	echo '<h2 class="woocommerce-loop-product__title">'.$product->post_title.'</h2>';

echo'</div>
</div>';
     
     
   		

   	}
 
   	
}

?>