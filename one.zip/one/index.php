<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

<main>
		<!-- banner section-->
		<section>
			<div class="banner_section">
				<div class="container">
					<div class="col-md-12">				
				<?php echo do_shortcode('[crellyslider alias="home_page"] '); ?>
				</div>
			</div>
				<!--<div id="myCarousel" class="carousel slide" data-ride="carousel">
					<!-- Wrapper for slides 
					<div class="carousel-inner">-->
						<?php
						  //$count=0;
						  //if( have_rows('banner_repeator',17) ){
						   //while ( have_rows('banner_repeator',17) ) : the_row();
						  // $img=get_sub_field('banner_repeator_image_1500x600',17);	
						?>
						<!--<div class="item <?php if ($count==0) {echo "active";} ?>">
							<img src="<?php echo $img; ?>" alt="Los Angeles" class="img-responsive banner_img">
						</div>-->
						<?php
						  //$count++;
						 // endwhile;
						 // }
						 // else{
						//	echo"No Images Found";
						 // }
						 ?>
						<!--<div class="item">
							<img src="images/banner.png" alt="Chicago" class="img-responsive banner_img">
						</div>
						<div class="item">
							<img src="images/banner.png" alt="New york" class="img-responsive banner_img">
						</div>-->
					</div>
				</div>
		</section>
		<!-- product section-->
		<section>
			<div class="product_section wow fadeInRight" data-wow-delay="0.2s">
				<div class="container">
					<p class="portfolio_head text-center"><?php the_field('homeproduct_head',17)?></p>
					<hr class="port_hr"></hr>
					<div class="col-md-12 heigeproduct">
						<div class="owl-carousel" id="owl-demo2"> 
							<?php
							  $count=0;
							  if( have_rows('homeproduct_repeator',17) ){
							   while ( have_rows('homeproduct_repeator',17) ) : the_row();
							   $heading=get_sub_field('homeproduct_head_repeator',17);
							   $paragraph=get_sub_field('homeproduct_text_repeator',17);
							    $img=get_sub_field('homeproduct_image_repeator',17);
							   
							?>
							<div class="item">
								<div class="pro_sect_fulborder">
									<div class="col-md-6 col-sm-6 pas">
										<p class="accondproduct"><?php echo $heading; ?></p>
										<p class="accord_deails"><?php echo $paragraph; ?></p>
									</div>
									<div class="col-md-6 col-sm-6 pas">
										<img src="<?php echo $img; ?>" class="img-responsive owl_imgproduct">
									</div>
								</div>
							</div> 
							<?php
							  $count++;
							  endwhile;
							  }
							  else{
								echo"No Images Found";
							  }
							 ?>
							<!--<div class="item">
								<div class="pro_sect_fulborder">
									<div class="col-md-6 col-sm-6 pas">
										<p class="accondproduct">Arcade-das Standard-Fenster</p>
										<p class="accord_deails">Bewahrte Losungen zum gunstigen Preis</p>
									</div>
									<div class="col-md-6 col-sm-6 pas">
										<img src="images/dhinatechproductimg17.jpg" class="img-responsive owl_imgproduct">
									</div>
								</div>
							</div>
							<div class="item">
								<div class="pro_sect_fulborder">
									<div class="col-md-6 col-sm-6 pas">
										<p class="accondproduct">Arcade-das Standard-Fenster</p>
										<p class="accord_deails">Bewahrte Losungen zum gunstigen Preis</p>
									</div>
									<div class="col-md-6 col-sm-6 pas">
										<img src="images/dhinatechproductimg17.jpg" class="img-responsive owl_imgproduct">
									</div>
								</div>
							</div>
							<div class="item">
								<div class="pro_sect_fulborder">
									<div class="col-md-6 col-sm-6 pas">
										<p class="accondproduct">Arcade-das Standard-Fenster</p>
										<p class="accord_deails">Bewahrte Losungen zum gunstigen Preis</p>
									</div>
									<div class="col-md-6 col-sm-6 pas">
										<img src="images/dhinatechproductimg17.jpg" class="img-responsive owl_imgproduct">
									</div>
								</div>
							</div>
							<div class="item">
								<div class="pro_sect_fulborder">
									<div class="col-md-6 col-sm-6 pas">
										<p class="accondproduct">Arcade-das Standard-Fenster</p>
										<p class="accord_deails">Bewahrte Losungen zum gunstigen Preis</p>
									</div>
									<div class="col-md-6 col-sm-6 pas">
										<img src="images/dhinatechproductimg17.jpg" class="img-responsive owl_imgproduct">
									</div>
								</div>
							</div>-->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- our work in action section -->
		<section>
			<div class="work_section">
				<div class="container border_line">
					<div class="col-md-2 col-sm-3 work_image wow fadeInLeft" data-wow-delay="0.4s">
						<img src="<?php the_field('work_section_image',17)?>" class="img-responsive wor_img">
					</div>
					<div class="col-md-10 col-sm-9 work_parasection wow fadeInDown" data-wow-delay="0.6s">
						<p class="work_head"><?php the_field('work_section_head',17)?></p>
						<div class="row rr">
							<?php
								$count=0;
								if( have_rows('work_section_repeator',17) ){
								while ( have_rows('work_section_repeator',17) ) : the_row();
								$img=get_sub_field('work_section_fonticon',17);
								$heading=get_sub_field('work_section_repeatorhead',17);
								$paragraph=get_sub_field('worksection_repeatpara',17);
							?>
							<div class="col-md-17 col-sm-6 accusantium">
								<span class="accut_icon"><i class="fa <?php echo $img; ?>"></i></span>
								<div class="acc_sect">
									<p class="accusentiun_head"><?php echo $heading; ?></p>
									<p class="accutim_para text-justify"><?php echo $paragraph; ?></p>
								</div>
							</div>
							<?php
								$count++;
								endwhile;
								}
								else{
									echo"No Images Found";
								}
							?>
							<!--<div class="col-md-17 col-sm-6 accusantium">
								<span class="accut_icon"><i class="fa fa-legal"></i></span>
								<div class="acc_sect">
									<p class="accusentiun_head">DOLAREMQUE</p>
									<p class="accutim_para text-justify">Lorem ipsum dolor sit amet,consectetur adipiscing elit, sed do eiusmod temper incidient utmagna aliqua.</p>
								</div>
							</div>
							<div class="col-md-17 col-sm-6 accusantium">
								<span class="accut_icon"><i class="fa fa-cogs"></i></span>
								<div class="acc_sect">
									<p class="accusentiun_head">LAUANTIUM</p>
									<p class="accutim_para text-justify">Lorem ipsum dolor sit amet,consectetur adipiscing elit, sed do eiusmod temper incidient utmagna aliqua.</p>
								</div>
							</div>
							<div class="col-md-17 col-sm-6 accusantium">
								<span class="accut_icon"><i class="fa fa-flask"></i></span>
								<div class="acc_sect">
									<p class="accusentiun_head">TOTAM REM</p>
									<p class="accutim_para text-justify">Lorem ipsum dolor sit amet,consectetur adipiscing elit, sed do eiusmod temper incidient utmagna aliqua.</p>
								</div>
							</div>
							<div class="col-md-17 col-sm-6 accusantium">
								<span class="accut_icon"><i class="fa fa-lightbulb-o"></i></span>
								<div class="acc_sect">
									<p class="accusentiun_head">APERIAM EAQUE</p>
									<p class="accutim_para text-justify">Lorem ipsum dolor sit amet,consectetur adipiscing elit, sed do eiusmod temper incidient utmagna aliqua.</p>
								</div>
							</div>
							<div class="col-md-17 col-sm-6 accusantium">
								<span class="accut_icon"><i class="fa fa-fire-extinguisher"></i></span>
								<div class="acc_sect">
									<p class="accusentiun_head">EAQUE ISPA QUAE</p>
									<p class="accutim_para text-justify">Lorem ipsum dolor sit amet,consectetur adipiscing elit, sed do eiusmod temper incidient utmagna aliqua.</p>
								</div>
							</div>-->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- portifolio section-->
			<!-- portifolio section-->
		<section>
			<div class="porfolio_section">
				<div class="container">
					<p class="portfolio_head text-center"><?php the_field('portfolio_head',17)?></p>
					<hr class="port_hr"></hr>
						<div class="port_gallery1"><?php echo do_shortcode('[wonderplugin_gridgallery id=1]'); ?></div>
					
					<!--<div class="row pofl">
						<!-- A basic setup of simple mode filter controls, all you have to do is use data-filter="all"
						for an unfiltered gallery and then the values of your categories to filter between them
						<ul class="simplefilter">
							<li class="active" data-filter="all">All</li>
							<li data-filter="1">WINDOWS</li>
							<li data-filter="2">DOORS& GATES</li>
							<li data-filter="3">SUN PRODUCTIONS</li>
							<li data-filter="17">WINTER GARDENS</li>
						</ul>
					</div>
					<div class="row pofl col-md-12 pl">
						<?php
								
							//if( have_rows('portfolio_repeator',17) ){
							//while ( have_rows('portfolio_repeator',17) ) : the_row();
							//$img=get_sub_field('portfolio_repeator_img',17);
						?>
						<!-- This is the set up of a basic gallery, your items must have the categories they belong to in a data-category
						attribute, which starts from the value 1 and goes up from there 
						<div class="filtr-container">
							<div class="col-xs-6 col-sm-3 col-md-3 filtr-item" data-category="1, 17, 5" data-sort="WINDOWS">
								<div class="pot_hov1">
									<div class="img_pot">
										<img class="img-responsive port_imgs" src="<?php echo $img; ?>" alt="sample image">
										<div class="im_porthov">
											<span class="pot_hv"><i class="fa fa-expand"></i></span>
										</div>
									</div>
								</div>
							</div>
							<?php
								//endwhile;
								//}
								//else{
								//	echo"No Images Found";
								//}
							?>
							<!--<div class="col-xs-6 col-sm-3 col-md-3 filtr-item" data-category="2, 1, 5" data-sort="DOORS& GATES">
								<div class="pot_hov1">
									<div class="img_pot">
										<img class="img-responsive port_imgs" src="images/port_2.png" alt="sample image">
										<div class="im_porthov">
											<span class="pot_hv"><i class="fa fa-expand"></i></span>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-6 col-sm-3 col-md-3 filtr-item" data-category="1, 3, 5" data-sort="SUN PRODUCTIONS">
								<div class="pot_hov1">
									<div class="img_pot">
										<img class="img-responsive port_imgs" src="images/port_3.png" alt="sample image">
										<div class="im_porthov">
											<span class="pot_hv"><i class="fa fa-expand"></i></span>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-6 col-sm-3 col-md-3 filtr-item" data-category="3, 2, 5" data-sort="WINDOWS">
								<div class="pot_hov1">
									<div class="img_pot">
										<img class="img-responsive port_imgs" src="images/port_17.png" alt="sample image">
										<div class="im_porthov">
											<span class="pot_hv"><i class="fa fa-expand"></i></span>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-6 col-sm-3 col-md-3 filtr-item" data-category="3, 17, 5" data-sort="WINTER GARDENS">
								<div class="pot_hov1">
									<div class="img_pot">
										<img class="img-responsive port_imgs" src="images/port_5.png" alt="sample image">
										<div class="im_porthov">
											<span class="pot_hv"><i class="fa fa-expand"></i></span>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-6 col-sm-3 col-md-3 filtr-item" data-category="2, 17, 5" data-sort="SUN PRODUCTIONS">
								<div class="pot_hov1">
									<div class="img_pot">
										<img class="img-responsive port_imgs" src="images/port_6.png" alt="sample image">
										<div class="im_porthov">
											<span class="pot_hv"><i class="fa fa-expand"></i></span>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-6 col-sm-3 col-md-3 filtr-item" data-category="1, 17, 5" data-sort="WINDOWS">
								<div class="pot_hov1">
									<div class="img_pot">
										<img class="img-responsive port_imgs" src="images/port_7.png" alt="sample image">
										<div class="im_porthov">
											<span class="pot_hv"><i class="fa fa-expand"></i></span>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-6 col-sm-3 col-md-3 filtr-item" data-category="2, 3, 5" data-sort="WINTER GARDENS">
								<div class="pot_hov1">
									<div class="img_pot">
										<img class="img-responsive port_imgs" src="images/port_8.png" alt="sample image">
										<div class="im_porthov">
											<span class="pot_hv"><i class="fa fa-expand"></i></span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>-->
				</div>	
			</div>	
		</section>
		<!-- client section-->
		<section>
			<div class="our_clients wow fadeInDown" data-wow-delay="0.8s">
				<div class="container">
					<p class="portfolio_head text-center"><?php the_field('client_head',17)?></p>
					<hr class="port_hr"></hr>
					<div class="col-md-12 pl">
						<div class="owl-carousel" id="owl-demo"> 
							<?php
								
								if( have_rows('clientsection_repeator',17) ){
								while ( have_rows('clientsection_repeator',17) ) : the_row();
								$img=get_sub_field('client_repeator_image',17);
							?>
							<div class="item">
								<img src="<?php echo $img; ?>" class="img-responsive owl_img">
							</div>  
							<?php
								endwhile;
								}
								else{
									echo"No Images Found";
								}
							?>
							<!--<div class="item">
								<img src="images/clients2.png" class="img-responsive owl_img">  
							</div>
							<div class="item">
								<img src="images/clients3.png" class="img-responsive owl_img">   
							</div>
							<div class="item">
								<img src="images/clients17.png" class="img-responsive owl_img">   
							</div>
							<div class="item">
								<img src="images/clients5.png" class="img-responsive owl_img">   
							</div>-->
						</div>
					</div>
				</div>
			</div>
		</section>
	</main>

<?php get_footer();
