<?php
/**
 * Template Name:ABOUT
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

<!-- banner section-->
		<section>
			<div class="container banner_section">
<div class="class="col-md-12">
				<?php echo do_shortcode('[crellyslider alias="aboutpagebanner"] '); ?>
				<!--<div id="myCarousel1" class="carousel slide" data-ride="carousel">
					 Wrapper for slides 
					<div class="carousel-inner">
						<div class="item active">
							<div class="abtbanner">
								<img src="images/bannerabout.png" alt="Los Angeles" class="img-responsive banner_img">
								<p class="bannerabt_text">Welcome to Schneider Bauelemente</p>
							</div>
						</div>
						<div class="item">
							<div class="abtbanner">
								<img src="images/bannerabout.png" alt="Los Angeles" class="img-responsive banner_img">
								<p class="bannerabt_text">Welcome to Schneider Bauelemente</p>
							</div>
						</div>
						<div class="item">
							<div class="abtbanner">
								<img src="images/bannerabout.png" alt="Los Angeles" class="img-responsive banner_img">
								<p class="bannerabt_text">Welcome to Schneider Bauelemente</p>
							</div>
						</div>
					</div>
				</div>-->
</div>
		</section>
		<!-- about section-->
		<section>
			<div class="about_pagesection">
				<div class="container">
					<div class="abot_page_headsm hidden-md hidden-lg text-center">
						<h3 class="aboutpage_head"><?php the_field('aboutpagesection_head1',4)?></h3>
						<hr class="about_line"></hr>
					</div>
					<div class="col-md-5 col-sm-12 abtpage_img">
						<img src="<?php the_field('about_section_firstimage',4)?>" class="img-responsive img_abtpge">
					</div>
					<div class="col-md-7 col-sm-12 aboutpage_para">
						<div class="hidden-sm hidden-xs">
							<h3 class="aboutpage_head"><?php the_field('aboutpagesection_head1',4)?></h3>
							<hr class="about_line"></hr>
						</div>
						<p class="aboutpage_para1 text-justify"><?php the_field('aboutpage_para1',4)?> </p>
						<p class="aboutpage_para1 text-justify"><?php the_field('aboutpage_para2',4)?></p> 
						
					</div>
				</div>
			</div>
		</section>
		<!-- what we provided-->
		<section>
			<div class="we_provided_section">
				<div class="container">
					<div class="col-md-6 col-sm-6 weprovis_half">
						<h3 class="weprovid_head"><?php the_field('we_provide_head',4)?></h3>
						<p class="aboutpage_para1 text-justify"><?php the_field('we_provide_para1',4)?></p>
						<p class="aboutpage_para1 text-justify"><?php the_field('we_provide_para2',4)?></p> 
					</div>
					<div class="col-md-6 col-sm-6 weprovis_half">
						<h3 class="weprovid_head"><?php the_field('our_mission_head',4)?></h3>
						<p class="aboutpage_para1 text-justify"><?php the_field('our_mission_para1',4)?></p>
						<p class="aboutpage_para1 text-justify"><?php the_field('our_mission_para2',4)?></p> 
					</div>
				</div>
			</div>
		</section>
		<!-- testimonial-->
		<section>
			<div class="abttestimonail_section">
				<div class="container">
					<div class="testmonialabt_head text-center">
						<p class="testabt_heah"><?php the_field('testimonial_head',4)?></p>
						<hr class="test_hr1"></hr>
					</div>
					<div class="roww">
						<div class="col-md-12">
							<div id="testimonial-slider" class="owl-carousel">
								<?php
									$count=0;
									if( have_rows('testimonial_repeator',4) ){
									while ( have_rows('testimonial_repeator',4) ) : the_row();
									$img=get_sub_field('testimonial_repeator_img1',4);
									$paragraph=get_sub_field('testimonial_repeator_para1',4);
									$name=get_sub_field('testimonial_repeator_name',4);
									$catagory=get_sub_field('testimonial_repeator_catagory',4);
									
									
								   
								?>
								<div class="testimonial">
									<div class="pic">
										<img src="<?php echo $img; ?>" alt="">
									</div>
									<div class="testimonial-content">
										<p class="description text-justify">
											<?php echo $paragraph; ?>
										</p>
										<h3 class="testimonial-title"><?php echo $name; ?>
											<small class="post"><?php echo $catagory; ?></small>
										</h3>
									</div>
								</div>
								<?php
									$count++;
									endwhile;
									}
									else{
										echo"No Images Found";
									}
								 ?>
								<!--<div class="testimonial">
									<div class="pic">
										<img src="images/dhinatechabuttestimonial.png" alt="">
									</div>
									<div class="testimonial-content">
										<p class="description text-justify">
											Lorem ipsum dolor sit amet, consectetur adipisicing elit. A aliquam amet animi blanditiis consequatur debitis dicta distinctio, enim error eum iste libero modi nam natus perferendis possimus quasi sint sit tempora voluptatem. Est, exercitationem id ipsa ipsum laboriosam perferendis temporibus! possimus quasi sint sit tempora voluptatem. Est, exercitationem id ipsa ipsum
										</p>
										<h3 class="testimonial-title">kristiana
											<small class="post">Web Designer</small>
										</h3>
									</div>
								</div>-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<?php get_footer(); ?>